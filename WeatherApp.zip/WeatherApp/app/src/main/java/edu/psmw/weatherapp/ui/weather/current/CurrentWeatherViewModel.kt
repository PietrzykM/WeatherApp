package edu.psmw.weatherapp.ui.weather.current

import androidx.lifecycle.ViewModel

class CurrentWeatherViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
